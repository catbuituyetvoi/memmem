<h1>ghjgh
<?php echo $id ?>