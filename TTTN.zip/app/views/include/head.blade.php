<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="Scotch">
<title> @yield('title') </title>
{{ HTML::style('css/foundation.css') }}
{{ HTML::script('js/jquery.min.js') }}
{{ HTML::script('js/foundation.min.js') }}
{{ HTML::script('js/main.js') }}
{{ HTML::script('js/learning.js') }}
{{ HTML::style('css/memmem.css') }}

