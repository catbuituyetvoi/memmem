@extends('layout.main')

@section('title','Learning  ')

@section('content')

	<div class="row">
		<div class="small-10 small-centered columns">
			<h2>learning</h2>
			<div class="learning" type="learning">

				<div id="loading">
					<img src="../img/loading.gif">
				Loading
				</div>
			</div>
		</div>
	</div>

@endsection
