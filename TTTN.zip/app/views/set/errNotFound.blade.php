@extends('layout.main')
@section('content')
	<h1>Không tìm thấy bộ từ này</h1>
@stop
