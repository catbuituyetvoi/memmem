<?php
Route::get('/testMimg', function(){
	echo Mimg::greeting();
});
