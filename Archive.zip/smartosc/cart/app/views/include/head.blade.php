<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="Scotch">
<title> @yield('title') </title>

{{ HTML::style('css/foundation.css') }}
{{ HTML::style('css/style.css') }}
{{ HTML::script('js/jquery.min.js') }}
{{ HTML::script('js/main.js') }}
