<div class="navBar row">
	<a href="{{ URL::route('home') }}">HOME</a>

	<a class="button alert small right" href="{{ URL::route('cart-view') }}">VIEW CART</a>
</div>