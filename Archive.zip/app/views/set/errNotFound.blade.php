@extends('layout.main')
@section('content')
	<div class="row whiteBg">
		<div class="small-10 columns">
			<h1>Không tìm thấy bộ từ này</h1>
		</div>
	</div>
@stop
